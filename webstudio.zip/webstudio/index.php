<?php
/**
 * The main template file
 *
 */

get_header();
?>
    <section class="content blog_section" id="blog_section">
        <div class="container">
            <h1 class="title">Блог</h1>
            <p class="des">Все про работу и жизнь, наши достижения</p>
            <?php pagination(); ?>
            <div class="row posts_row">
                <?php if (have_posts()) : while (have_posts()) : the_post();
                    get_template_part('template-parts/blog', get_post_type()); ?>
                <?php endwhile; endif; ?>
            </div>
        </div>

        <?php if (is_home()): ?>
            <div class="container">
                <div class="row tags_container">
                    <div class="col-lg-12">
                        <h2 class="second_title">Посты по темам</h2>
                    </div>
                    <div class="col-lg-12">
                        <?php $tags = get_tags(); ?>
                        <ul class="tags_list">
                            <?php foreach ($tags as $tag): ?>
                                <?php $tag_link = get_tag_link($tag->term_id); ?>
                                <li><a href='<?php echo $tag_link; ?>' title='<?php echo $tag->name; ?> Tag'
                                       class='<?php echo $tag->slug ?>'>#<?php echo $tag->name; ?></a> <span><?php echo $tag->count ?></span></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-lg-12">
                        <a href="#" data-clicks="true" data-text="показать еще" class="btn_bordered more">показать еще</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </section>

<?php get_footer(); ?>