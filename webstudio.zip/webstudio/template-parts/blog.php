
<div class="col-lg-4 posts_class">
    <div class="post_list_box">
        <div class="image_holder">
            <img src="<?php the_post_thumbnail_url(); ?>" alt="">
        </div>
        <p class="date"><?php echo get_the_date('j F Y'); ?></p>
        <?php $maxchar = 100; ?>
        <?php $text = strip_tags(get_the_excerpt()); ?>
        <a href="<?php the_permalink(); ?>" title="<?php echo mb_substr($text, 0, $maxchar) ?>"
           class="short_text"><?php echo mb_substr($text, 0, $maxchar) ?>...</a>
        <ul class="blog_tags_list nav">
            <?php echo show_tags(); ?>
        </ul>
    </div>
</div>
