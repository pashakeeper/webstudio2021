<?php
/**
 * The template for displaying single posts and pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

get_header();
?>

<div class="content post">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php $titl = get_the_title(); ?>
                <h2 class="title"><?php echo $titl; ?></h2>
                <div class="row">
                    <div class="col-lg-2">
                        <span class="date"><?php echo get_the_date('j F Y'); ?></span>
                    </div>
                    <div class="col-lg-6">
                        <ul class="nav post_nav">
                            <li> <?php previous_post_link('%link', '<span><i class="fa fa-long-arrow-alt-left"></i></span>Предыдущая'); ?></li>
                            <li><?php next_post_link('%link', 'Следующая<span><i class="fa fa-long-arrow-alt-right"></i></span>'); ?></li>
                        </ul>


                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="post_box">
                    <?php

                    if (have_posts()) {

                        while (have_posts()) {
                            the_post();

                            get_template_part('template-parts/content', get_post_type());
                        }
                    }

                    ?>
                    <a href="#" data-text="заказать звонок" class="take_call btn_bordered">заказать звонок</a>
                </div>

            </div>
            <?php wp_reset_query(); ?>
            <div class="col-lg-3 tags_box ">
                <?php echo show_tags2(); ?>
            </div>
        </div>
    </div>
</div>
</div>
<!--end of content-->

<!--posts list-->
<section class="post_list">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title">Возможно вас заинтересует</h2>
            </div>
            <!-- из какой рубрики выводить (можно убрать, если не нужно), количество постов-->
            <?php $the_query = new WP_Query('cat=1&showposts=3&orderby=rand'); ?>
            <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                <div class="col-lg-4">
                    <div class="post_list_box">
                        <div class="image_holder">
                            <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                        </div>
                        <p class="date"><?php echo get_the_date('j F Y'); ?></p>
                        <a href="<?php the_permalink() ?>" class="short_text"><?php the_title(); ?></a>
                        <ul class="nav">
                            <?php $tags = get_the_tags(); ?>
                            <?php foreach ($tags as $tagitem): ?>
                                <li class="ml-1 mr-1">
                                    <a href="<?php get_tag_link($tagitem->term_id) ?>"
                                       class="tag">#<?php echo $tagitem->name ?></a>
                                </li>
                            <?php endforeach; ?>
                        </ul>

                    </div>
                </div>
            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
        </div>
    </div>
</section>
<!--end of post list-->


<?php get_footer(); ?>
