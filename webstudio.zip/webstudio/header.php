<?php
/**
 * Header file for the Twenty Twenty WordPress default theme.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

?><!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>

<head>

	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" >

	<link rel="profile" href="https://gmpg.org/xfn/11">



	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;900&display=swap"
	rel="stylesheet">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/libs.min.css" media="(prefers-reduced-motion: no-preference)">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/media.css">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> <?php if( is_front_page() ):?> id="front_page" <?php endif;?>>
	<!--Header-->
	<header class="header">
		<div class="container">
			<div class="pre_header">
				<div class="row justify-content-between">
					<div class="col-lg-4">
						<a target="_blank" href="<?php the_field('google_link', 'option'); ?>" class="address">
							<i class="fas fa-map-marker-alt"></i>
							<?php the_field('address', 'option'); ?>
						</a>
					</div>
					<div class="col-lg-4 d-flex flex-wrap align-items-center justify-content-end pils_container ">
						<span>Тема: </span>
						<ul class="nav nav-pills" id="pills-tab" role="tablist">
							<li class="nav-item" role="presentation">
								<button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
								data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
								aria-selected="true">Темная
							</button>
						</li>
						<li class="nav-item" role="presentation">
							<button class="nav-link second" id="pills-profile-tab" data-bs-toggle="pill"
							data-bs-target="#pills-profile" type="button" role="tab"
							aria-controls="pills-profile" aria-selected="false">Светлая
						</button>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="main_header">
		<div class="row">
			<div class="col-lg-2 col-sm-4 col-4">
				<?php twentytwenty_site_logo(); ?>
			</div>
			<div class="col-lg-5 main_menu_box">
				<?php wp_nav_menu( array(
					'theme_location'  => 'primary',
					'menu'            => '',
					'container'       => false,
					'container_class' => '',
					'container_id'    => '',
					'menu_class'      => 'nav main_menu justify-content-between',
					'menu_id'         => 'main_menu',
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'before'          => '',
					'after'           => '',
					'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
					'depth'           => 0,
					'walker'          => '',
				) ); ?>
				<div class="main_menu_container">
					<?php dynamic_sidebar( 'sidebar-3' ); ?>
					<div class="close position-absolute">
						<svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
							<line x1="0.353553" y1="0.646447" x2="14.3536" y2="14.6464" stroke="white"/>
							<line x1="14.3536" y1="1.35355" x2="0.353551" y2="15.3536" stroke="white"/>
						</svg>
					</div>
					<div class="main_menu_container__podmenu main_menu_container__podmenu_1">
						<div class="main_menu_container__prev">
							<svg width="35" height="8" viewBox="0 0 35 8" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M0.646446 3.64645C0.451183 3.84171 0.451183 4.15829 0.646446 4.35355L3.82843 7.53553C4.02369 7.7308 4.34027 7.7308 4.53553 7.53553C4.7308 7.34027 4.7308 7.02369 4.53553 6.82843L1.70711 4L4.53553 1.17157C4.7308 0.976311 4.7308 0.659728 4.53553 0.464466C4.34027 0.269204 4.02369 0.269204 3.82843 0.464466L0.646446 3.64645ZM35 3.5L1 3.5V4.5L35 4.5V3.5Z" fill="white"/>
							</svg>
						</div>
						<div class="main_menu_container__wrap">
							<div class="main_menu_container__column">
								<a href="<?php echo bloginfo('url'); ?>/vedenie-stranits-v-sots-setyah/" class="main_menu_container__title">Ведение соц.сетей</a>
								<?php wp_nav_menu( array(
									'menu'            => 'Ведение Соц сетей',
									'container'       => false,
									'container_class' => '',
									'container_id'    => '',
									'menu_class'      => 'animation-link',
									'menu_id'         => 'main_menu',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => '',
								) ); ?>
							</div>
							<div class="main_menu_container__column">
								<a href="<?php echo bloginfo('url'); ?>/prodvizhenie-v-sots-setyah/" class="main_menu_container__title">Продвижение соц.сетей</a>
								<?php wp_nav_menu( array(
									'menu'            => 'Продвижение соц сетей',
									'container'       => false,
									'container_class' => '',
									'container_id'    => '',
									'menu_class'      => 'animation-link',
									'menu_id'         => 'main_menu',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => '',
								) ); ?>
							</div>
							<div class="main_menu_container__column">
								<a href="#" class="main_menu_container__title">Другое</a>
								<?php wp_nav_menu( array(
									'menu'            => 'Другое',
									'container'       => false,
									'container_class' => '',
									'container_id'    => '',
									'menu_class'      => 'animation-link',
									'menu_id'         => 'main_menu',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => '',
								) ); ?>
							</div>
						</div>
					</div>
					<div class="main_menu_container__podmenu main_menu_container__podmenu_2">
						<div class="main_menu_container__prev">
							<svg width="35" height="8" viewBox="0 0 35 8" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M0.646446 3.64645C0.451183 3.84171 0.451183 4.15829 0.646446 4.35355L3.82843 7.53553C4.02369 7.7308 4.34027 7.7308 4.53553 7.53553C4.7308 7.34027 4.7308 7.02369 4.53553 6.82843L1.70711 4L4.53553 1.17157C4.7308 0.976311 4.7308 0.659728 4.53553 0.464466C4.34027 0.269204 4.02369 0.269204 3.82843 0.464466L0.646446 3.64645ZM35 3.5L1 3.5V4.5L35 4.5V3.5Z" fill="white"/>
							</svg>
						</div>
						<div class="main_menu_container__wrap">
							<?php wp_nav_menu( array(
									'menu'            => 'Подменю 2',
									'container'       => false,
									'container_class' => '',
									'container_id'    => '',
									'menu_class'      => 'menu__inline__link animation-link',
									'menu_id'         => 'main_menu',
									'echo'            => true,
									'fallback_cb'     => 'wp_page_menu',
									'before'          => '',
									'after'           => '',
									'link_before'     => '',
									'link_after'      => '',
									'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
									'depth'           => 0,
									'walker'          => '',
								) ); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-5 col-sm-8 col-8 d-flex flex-wrap">
				<a href="tel:<?php the_field('phone_format', 'option'); ?>" class="phone"><i class="fa fa-phone-alt"></i><?php the_field('phone', 'option'); ?></a>
				<div class="button_side">
					<a href="#" data-text="Заказать звонок" class="btn_bordered call" style="font-weight: 700;">Заказать звонок</a>
					<a href="#" id="modal_open" data-text="Получить коммерческое предложение"
					class="btn_bordered take_offer" style="font-weight: 700;">Получить
				коммерческое предложение</a>
			</div>
			<div class="burger">
				<span></span>
				<span></span>
				<span></span>
			</div>
		</div>
		<div class="mobile_menu">
			<?php wp_nav_menu( array(
				'theme_location'  => 'primary',
				'menu'            => '',
				'container'       => false,
				'container_class' => '',
				'container_id'    => '',
				'menu_class'      => 'nav main_menu justify-content-between',
				'menu_id'         => 'main_menu',
				'echo'            => true,
				'fallback_cb'     => 'wp_page_menu',
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
				'depth'           => 0,
				'walker'          => '',
			) ); ?>
			<div class="main_menu_container">
				<?php dynamic_sidebar( 'sidebar-3' ); ?>
				<div class="close position-absolute">
					<svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
						<line x1="0.353553" y1="0.646447" x2="14.3536" y2="14.6464" stroke="white"/>
						<line x1="14.3536" y1="1.35355" x2="0.353551" y2="15.3536" stroke="white"/>
					</svg>
				</div>
			</div>
			<div class="button_side">
				<a href="#"  data-text="Заказать звонок" class="btn_bordered call">Заказать звонок</a>
				<a href="#" id="modal_open" data-text="Получить коммерческое предложение" class="btn_bordered take_offer">Получить
				коммерческое предложение</a>
			</div>
			<div class="col-lg-4 d-flex flex-wrap align-items-center justify-content-center pils_container">
				<span>Тема: </span>
				<ul class="nav nav-pills" id="pills-tab" role="tablist">
					<li class="nav-item" role="presentation">
						<button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
						data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
						aria-selected="true">Темная
					</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link second" id="pills-profile-tab" data-bs-toggle="pill"
					data-bs-target="#pills-profile" type="button" role="tab"
					aria-controls="pills-profile" aria-selected="false">Светлая
				</button>
			</li>
		</ul>
	</div>
</div>
</div>

</div>
</div>
</header>

<div class="overlay-blur"></div>
<!--end of header-->