<?php get_header(); ?>


<section class="content case_section">
    <div class="container">
        <div class="row">
            <h1 class="title w-100"><?php the_title(); ?></h1>
            <div class="box">
                <ul class="breadcrumbs_list  nav">
                    <?php $categories = get_the_category(); ?>
                    <?php foreach ($categories as $category): ?>
                        <li>
                            <a href="#"><?php echo $category->name; ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php $test = get_field('video_sale_page_case') ?>
            <div class="content_box">
                <div class="row">
                    <?php if ($test['video_image']): ?>
                    <div class="col-lg-6 content pt-0 pb-5">
                        <div class="video_reviews_box pt-0">
                            <div class="video_review">
                                <div class="placeholder_reviews">
                                    <?php if ($test['video_image']): ?>
                                        <img src="<?php echo $test['video_image'] ?>" alt="">
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <div data-toggle="modal" data-src="<?php echo $test['video_link_sale']; ?>"
                                         data-target="#modal_Video" class="btn_play">
                                        <i class="fa fa-play"></i>
                                    </div>
                                </div>
                                <iframe
                                        src="<?php echo $test['video_link_sale']; ?>">
                                </iframe>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="modal_Video" tabindex="-1" role="dialog"
                         aria-labelledby="exampleModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog  modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <iframe class="embed-responsive-item" src="" id="video" allowscriptaccess="always"
                                        allow=""></iframe>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php $text_rght = get_field('text_right_custom'); ?>
                    <?php if ($text_rght): ?>
                    <div class="col-lg-6 pb-6">
                        <?php echo $text_rght; ?>
                    </div>
                    <?php endif; ?>
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <!--            slider box-->
            <div class="slider_same_work_box w-100">
                <!--                slider-->
                <?php $args = array(
                    'post_type' => 'case',
                    'posts_per_page' => 0,
                    'orderby' => 'rand',

                );
                query_posts($args); ?>
                <div class="slider_same_work">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <div class="slide" style="background-image: url(<?php echo get_the_post_thumbnail_url(); ?>)">
                            <p class="slide_title"><?php the_title(); ?></p>
                            <p class="slide_short_text"><?php the_excerpt(); ?></p>
                            <div class="hidden_box">
                                <?php global $post; ?>
                                <ul class="breadcrumbs_list nav">
                                    <?php $categories = get_the_category($post->ID); ?>
                                    <?php foreach ($categories as $category): ?>
                                        <li>
                                            <a href="<?php echo get_category_link($category->term_id); ?>"><?php echo $category->name; ?></a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php $stat_case = get_field('stat'); ?>
                                <div class="row stat_row align-items-center">
                                    <?php foreach ($stat_case as $stat): ?>
                                        <div class="col-sm-6 d-flex align-items-center">
                                            <img src="<?php echo $stat['icon_stat']; ?>" alt="">
                                            <div class="info_side">
                                                <div class="quant"><?php echo $stat['quant_stat']; ?></div>
                                                <div class="text"><?php echo $stat['name_stat']; ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <a href="<?php echo the_permalink() ?>" data-text="подробнее"
                                   class="btn_bordered">подробнее</a>
                            </div>
                        </div>
                    <?php endwhile; endif; ?>
                </div>
                <!--                end of slider-->
            </div>
            <!--            end of slide box-->
        </div>
    </div>
    <div class="container action_box">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <div class="box_need">
                    <h2 class="title">Не получается увеличить продажи?</h2>
                    <p class="des">Мы точно знаем как вам помочь!</p>
                    <p class="text">Оставьте заявку и мы сделаем Вам уникальное <br> предложение, которое подойдет
                        именно Вам</p>
                    <a href="#" class="btn_bordered">Получить коммерческое <br> предложение</a>
                </div>
            </div>
            <div class="col-lg-7">
                <img class="image" src="<?php echo get_template_directory_uri(); ?>/assets/img/cyber_03.png" alt="">
            </div>
        </div>
    </div>
</section>


<?php get_footer(); ?>
