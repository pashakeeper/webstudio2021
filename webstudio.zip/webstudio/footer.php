<?php
/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

?>

<!--Footer-->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 footer_logo_box">
                <a href="/" class="footer_logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/footer_logo.png" alt="">
                </a>
                <div class="info_footer mob">
                    <ul class="footer_list nav">
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>
                        <li><a href="#"><i class="fab fa-youtube-square"></i></a></li>
                        <li><a href="#"><i class="fab fa-vk"></i></a></li>
                    </ul>
                </div>
                <p class="copyright">© 2016-2021 TIMELIFE</p>
            </div>
            <div class="col-lg-5 footer_menu_box">
                <?php wp_nav_menu( array(
                    'theme_location'  => '',
                    'menu'            => 'footer_menu',
                    'container'       => '',
                    'container_class' => '',
                    'container_id'    => '',
                    'menu_class'      => 'nav footer_menu',
                    'menu_id'         => 'footer_menu',
                    'echo'            => true,
                    'fallback_cb'     => 'wp_page_menu',
                    'before'          => '',
                    'after'           => '',
                    'link_before'     => '',
                    'link_after'      => '',
                    'items_wrap'      => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
                    'depth'           => 0,
                    'walker'          => '',
                ) ); ?>
                <ul class="privace_list nav">
                    <li><a href="#">Политика Конфиденциальности</a></li>
                    <li><a href="#">Согласие на обработку персональных данных</a></li>
                </ul>
            </div>
            <div class="col-lg-5 ml-auto">
                <div class="row">
                    <div class="col-lg-5 info_box">
                        <div class="info_footer mt-0">
                            <i class="fa fa-phone-alt"></i>
                            <a href="#">8 (930) 401-93-48</a>
                        </div>
                        <div class="info_footer small_hidden social">
                            <?php $social = get_field('social','option') ?>
                            <ul class="footer_list nav">
                                <li><a href="<?php echo $social['instagram']; ?>"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="<?php echo $social['facebook']; ?>"><i class="fab fa-facebook-square"></i></a></li>
                                <li><a href="<?php echo $social['youtube']; ?>"><i class="fab fa-youtube-square"></i></a></li>
                                <li><a href="<?php echo $social['vk']; ?>"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-7 info_box">
                        <?php $info = get_field('email', 'option') ?>
                        <?php foreach ($info as $item): ?>
                        <div class="info_footer">
                            <i class="fa fa-envelope"></i>
                            <a href="#"><?php echo $item['mail']; ?></a>
                        </div>
                        <?php endforeach; ?>
                        <ul class="privace_list mob">
                            <li><a href="#">Политика Конфиденциальности</a></li>
                            <li><a href="#">Согласие на обработку персональных данных</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--end of footer-->
<a href="#"  class="btn_up" id="button"></a>
<!--end of content-->


<!--pop up-->
<div id="overlay"></div>
<div class="modal_window" id="modal_window">
    <div id="close" class="close_modal"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/close.png" alt=""></div>
    <div class="container">
        <?php echo do_shortcode('[contact-form-7 id="3809" title="Форма 2"]'); ?>
    </div>
</div>
<!--pop up-->

<div class="modal_window " id="modal_2">
    <div id="close_2" class="close_modal"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/close.png" alt=""></div>
    <div class="container">
        <div class="row">
            <p class="modal_title">Заполните форму</p>
            <p class="modal_des">Наши специалисты свяжуться с Вами и предоставять бесплатную консультацию по вашему
                заданию</p>
            <div class="modal_form_box w-100">
                <?php echo do_shortcode('[contact-form-7 id="407" title="Контактная форма 1"]');	 ?>
            </div>
        </div>
    </div>
</div>



<script src="<?php echo get_template_directory_uri(); ?>/assets/js/libs.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf"
crossorigin="anonymous"></script>
<script src="<?php echo get_template_directory_uri(); ?>/assets/js/scripts.js"></script>

<?php wp_footer(); ?>

</body>
</html>
