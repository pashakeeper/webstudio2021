<?php
/*
    Template Name: Продающая страница
    Template Post Type: post, page, product
*/
get_header(); ?>


    <!--sale section-->
    <section class="sale_section pb-5">
        <div class="container">
            <div class="row content_row">
                <?php $thumb = get_the_post_thumbnail_url(); ?>
                <?php $test = get_field('video_sale_page') ?>
                <div class="col-lg-<?php if (!empty($thumb) || !empty($test)): ?>6<?php else: ?>12<?php endif; ?>">
                    <h1 data-text="<?php the_title(); ?>" class="title"><?php the_title(); ?></h1>
                    <div class="des"><?php the_content(); ?></div>
                </div>
                <?php if (!empty($thumb)): ?>
                    <div class="col-lg-6">
                        <img class="image wow fadeInRight" data-wow-offset="150" data-wow-delay="150"
                             data-wow-duration="2s" src="<?php echo $thumb ?>" alt="IMG">
                    </div>
                <?php else: ?>
                    <div class="col-lg-6 content sale_video p-0">
                        <div class="video_reviews_box">
                            <div class="video_review">
                                <div class="placeholder_reviews">
                                    <?php if ($test['video_image']): ?>
                                        <img src="<?php echo $test['video_image'] ?>" alt="">
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <div data-toggle="modal" data-src="<?php echo $test['video_link_sale'] ?>"
                                         data-target="#modal_Video" class="btn_play">
                                        <i class="fa fa-play"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="modal_Video" tabindex="-1" role="dialog"
                         aria-labelledby="exampleModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog  modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <iframe style="width: 100% !important;" class="embed-responsive-item" src="" id="video"
                                        allowscriptaccess="always" allow="autoplay"></iframe>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!--end of sale section-->
    <style>
        .filter_portfolio__title {
            height: 64px;
            line-height: 64px;
            white-space: nowrap;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 16px;
            padding-left: 18px;
            padding-right: 30px;
            border-radius: 5px;
        }

        .radiant .filter_portfolio__title {
            border: 1px solid rgba(0, 0, 0, 0.1);
        }

        .radiant .des {
            color: #333;
        }

        .radiant .portfolio_section .filter_box {
            border-top: 1px solid rgba(0, 0, 0, .1);
        }
    </style>


    <!--Section 1-->
<?php $adv_item = get_field('reklama'); ?>
    <section class="section_01 <?php if (empty($adv_item)): ?>d-none <?php else: ?> <?php endif; ?>" id="section_01">
        <div class="container">
            <div class="row">
                <?php if (!empty($adv_item)): ?>
                    <?php foreach ($adv_item as $item): ?>
                        <div class="col-lg-<?php if (count($adv_item) < 2): ?>12<?php else: ?>6<?php endif; ?>">
                            <div class="advertising_box">
                                <?php if (!empty($item['image'])): ?>
                                    <img src="<?php echo $item['image'] ?>" alt="IMG">
                                <?php else: ?>
                                <?php endif; ?>
                                <h3><?php echo $item['title'] ?></h3>
                                <?php echo $item['content'] ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
            </div>
        </div>
    </section>
    <!--end of section 1-->
    <!--section 2-->
    <section class="section_02" id="section_02">
        <div class="container">
            <?php $adv_box = get_field('advantages'); ?>
            <?php foreach ($adv_box

                           as $adv_item): ?>
            <div class="row sale_row">
                <div class="col-lg-12">
                    <?php $title = $adv_item ?>
                    <h2 class="title"><?php echo $title['title']; ?></h2>
                </div>
                <?php $advantages_item = $adv_item ?>
                <?php if (!empty($advantages_item['advantage'])): ?>
                    <?php foreach ($advantages_item['advantage'] as $item): ?>
                        <div class="col-lg-<?php if (count($advantages_item['advantage']) > 1): ?>4<?php else: ?>12<?php endif; ?>">
                            <div class="adv_box"
                                 style="<?php if (count($advantages_item['advantage']) > 1): ?>max-width: 100% !important;<?php else: ?><?php endif; ?>">
                                <?php if (!empty($item['icon'])): ?>
                                    <img src="<?php echo $item['icon']; ?>" alt="IMG">
                                <?php else: ?>
                                <?php endif; ?>
                                <h4><?php echo $item['title_box']; ?></h4>
                                <?php echo $item['text']; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
                <?php endforeach; ?>
                <?php $adv_content_item = $adv_item ?>
                <?php if ($adv_content_item['content_adv']): ?>
                <div class="col-lg-12">
                    <div class="toggle_content">
                        <?php echo $adv_content_item['content_adv']; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
            <?php if (!$adv_content_item): ?>
            <?php else: ?>
            <?php $post_id = get_the_ID(); ?>
            <?php if ($post_id == 623): ?>
            </div>
            </div>
            </div>
            </div>
            <?php endif; ?>
                <div class="col-lg-12">
                    <a href="#" id="read_adv_posts" data-clicks="true" data-text="читать полностью"
                       class="read_more btn_bordered_2">читать
                        полностью</a>
                </div>
            <?php endif; ?>
    </section>


<?php if ($post_id == 753): ?>
<?php endif; ?>

    <!-- end of section 2 -->

<?php
$id__cat__page = get_field('id_cat_page');
if ($id__cat__page) {
    ?>

    <section class="portfolio_section" id="portfolio_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 mb-5">
                    <?php $pre_title = get_field('adv_slider_group') ?>
                    <?php if (!empty($pre_title['title'])): ?>
                        <h2 class="title"><?php echo $pre_title['title'] ?></h2>
                    <?php else: ?>
                        <?php $pre_title = get_field('adv_slider_group', 'option') ?>
                        <h2 class="title"><?php echo $pre_title['title'] ?></h2>
                    <?php endif; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        </div>
        <div class="container content pt-0">
            <div class="row">
                <div class="col-lg-12">
                    <?php
                    $args = array(
                        'post_type' => 'case',
                        'posts_per_page' => -1,
                        'cat' => $id__cat__page,
                        'paged' => 1,
                        'order' => 'ASC',
                    ); ?>
                    <!-- Slider-->
                    <div class="slider_sell_page">
                        <?php if (query_posts($args)): ?>
                            <?php while (have_posts()) : the_post(); ?>
                                <!-- Slide-->
                                <div class="slide">
                                    <div class="container">
                                        <?php $field_slide = get_field('kes__descr__true'); ?>
                                        <?php if ($field_slide): ?>
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <?php if (have_rows('kes__descr__left')):
                                                            while (have_rows('kes__descr__left')): the_row();
                                                                ?>
                                                                <p class="slider_title"><?php the_sub_field('kes__descr__left__title') ?></p>

                                                                <p class="slider_text"><?php the_sub_field('kes__descr__left__text') ?></p>
                                                                <p class="slider_des"><?php the_sub_field('kes__descr__left__des') ?></p>
                                                                <img class="slider_frame"
                                                                     src="<?php the_sub_field('kes__descr__img') ?>"
                                                                     alt="">
                                                            <?php endwhile; ?>

                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <?php if (have_rows('kes__descr__right')):
                                                            while (have_rows('kes__descr__right')): the_row();
                                                                ?>
                                                                <img class="right_image"
                                                                     src="<?php the_sub_field('kes__descr__right__img') ?>"
                                                                     alt="">
                                                            <?php endwhile; ?>

                                                        <?php endif; ?>
                                                        <div class="row stat_row justify-content-center align-items-center">
                                                            <?php
                                                            // проверяем есть ли в повторителе данные
                                                            if (have_rows('kes__descr__vantage')):

                                                                // перебираем данные
                                                                while (have_rows('kes__descr__vantage')) : the_row();

                                                                    ?>
                                                                    <div class="col-sm-6 col-6 d-flex justify-content-center align-items-center">
                                                                        <p><img loading="lazy"
                                                                                class="alignnone size-full wp-image-526"
                                                                                src="<?php the_sub_field('kes__descr__vantage__img'); ?>"
                                                                                alt="" width="64" height="64"></p>
                                                                        <div class="info_side">
                                                                            <p class="quant"><?php the_sub_field('kes__descr__vantage__title'); ?></p>
                                                                            <p class="text"><?php the_sub_field('kes__descr__vantage__text'); ?></p>
                                                                        </div>
                                                                    </div>
                                                                <?php

                                                                endwhile;

                                                            else :

                                                                // вложенных полей не найдено

                                                            endif;

                                                            ?>
                                                        </div>
                                                        <div class="row btn_row">
                                                            <a class="more btn_bordered"
                                                               href="<?php the_permalink(); ?>" data-text="Подробнее"
                                                               tabindex="0">Подробнее</a><br>
                                                            <a class="result btn_bordered" tabindex="0"
                                                               href="<?php the_permalink(); ?>"
                                                               data-text="хочу такие результаты">хочу такие
                                                                результаты</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <h2><?php the_title(); ?></h2>
                                            <div class="row align-items-center">
                                                <div class="col-lg-12 text-center"
                                                     style="max-height: 750px;height: 100%;">
                                                    <img style="max-height: 500px"
                                                         src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/no_info.jpg"
                                                         alt="">
                                                    <h1 class="second_title">К сожалению нету краткого описания</h1>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!--                    end of slide-->
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                    <!--                end of slider-->
                </div>
            </div>
        </div>
    </section>

    <?php
}
?>


    <!--section 4-->
<?php
$url = $_SERVER['REQUEST_URI'];
$postid = url_to_postid($url);
// проверяем есть ли в повторителе данные
if (have_rows('call_to_action_block', $postid)):

    // перебираем данные
    while (have_rows('call_to_action_block', $postid)) : the_row();

        // отображаем вложенные поля

        ?>
        <section class="section_04" id="section_04">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="box_need">
                            <h2 class="title"><?php the_sub_field('title_action'); ?></h2>
                            <?php the_sub_field('text_action'); ?>
                            <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                                коммерческое предложение</a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <img class="image wow fadeInRight" data-wow-offset="150" data-wow-delay="150"
                             data-wow-duration="2s"
                             src="<?php echo bloginfo('url') ?>/wp-content/uploads/2021/04/cyber_01.png" alt="">
                    </div>
                </div>
            </div>
        </section>
    <?php

    endwhile;

else :


endif;

?>
    <!-- end of section 4-->

    <!--end of clients slider-->

    <!--section 5-->
    <section class="section_05" id="section_05">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php $tarif_content = get_field('content_before_tarif', $postid); ?>
                    <?php if (!empty($tarif_content)): ?>
                        <?php echo $tarif_content ?>
                    <?php else: ?>
                        <?php $tarif_content = get_field('content_before_tarif', 'option'); ?>
                        <?php echo $tarif_content; ?>
                    <?php endif; ?>

                </div>
                <?php $plans = get_field('tarif_plans', $postid); ?>
                <?php if (!empty($plans)): ?>
                    <?php foreach ($plans as $plan): ?>
                        <div class="tariff_plan_box">
                            <div class="tariff_plan_box__head"
                                 style="background-image: linear-gradient(135deg, <?php echo $plan['from']; ?> 30%, <?php echo $plan['to']; ?> 100%);">
                                <?php echo $plan['plan_name']; ?>
                                <?php echo $plan['plan_des']; ?>
                            </div>
                            <?php echo $plan['price_dollar']; ?>
                            <p class="price_ru"><?php echo $plan['price_rub']; ?></p>
                            <?php echo $plan['список']; ?>
                            <a href="#" data-text="оставить заявку" class="btn_bordered">оставить заявку</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php $plans = get_field('tarif_plans', 'option'); ?>
                    <?php foreach ($plans as $plan): ?>
                        <div class="tariff_plan_box">
                            <div class="tariff_plan_box__head"
                                 style="background-image: linear-gradient(135deg, <?php echo $plan['from']; ?> 30%, <?php echo $plan['to']; ?> 100%);">
                                <?php echo $plan['plan_name']; ?>
                                <?php echo $plan['plan_des']; ?>
                            </div>
                            <?php echo $plan['price_dollar']; ?>
                            <p class="price_ru"><?php echo $plan['price_rub']; ?></p>
                            <?php echo $plan['список']; ?>
                            <a href="#" data-text="оставить заявку" class="btn_bordered">оставить заявку</a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
            </div>
        </div>
    </section>
    <!--end of section 5-->
<?php get_footer(); ?>