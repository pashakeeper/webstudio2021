<?php
/*
    Template Name: Услуги и цены
    Template Post Type: post, page, product
*/
get_header(); ?>
<section class="sevices_section content" id="services_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title"><?php the_title(); ?></h2>
            </div>
            <div class="row serv_row">
                <?php $services = get_field('services_page'); ?>
                <?php foreach ($services as $serv_item): ?>
                    <div class="col-lg-4">
                        <div class="serv_box">
                            <div class="serv_box__image_holder">
                                <img src="<?php echo $serv_item['image_serv']; ?>" alt="">
                            </div>
                            <div class="serv_box_content">
                                <h3><?php echo $serv_item['title_serv'] ?></h3>
                                <?php
                                $maxchar = 152;
                                $text = strip_tags($serv_item['content_serv']);
                                echo mb_substr($text, 0, $maxchar);
                                ?>
                            </div>
                            <div class="price">Цена от <span><?php echo $serv_item['price_serv']; ?> ₽</span></div>
                            <a href="<?php echo $serv_item['link_serv'] ?>" data-text="Подробнее" class="btn_bordered">Подробнее</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="col-lg-12"><a data-text="на главную" href="/"
                                          class="all_serv btn_bordered">на главную</a></div>

            </div>
        </div>
    </div>
</section>
<section class="reviews_section content" id="reviews_section">
    <div class="container action_box">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <div class="box_need">
                    <h2 class="title">Нужен сайт
                        или продвижение?</h2>
                    <p class="des">Мы точно знаем как вам помочь!</p>
                    <p class="text">Оставьте заявку и мы сделаем Вам уникальное предложение, которое подойдет именно
                        Вам</p>
                    <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                        коммерческое <br> предложение</a>
                </div>
            </div>
            <div class="col-lg-7">
                <img class="image" src="<?php echo get_template_directory_uri(); ?>/assets/img/cyber_01.png" alt="">
            </div>
        </div>
    </div>
</section>


<?php get_footer(); ?>
