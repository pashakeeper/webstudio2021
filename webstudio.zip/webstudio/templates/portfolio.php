<?php
/*
    Template Name: Портфолио (Кейсы)
    Template Post Type: post, page, product
*/
get_header(); ?>


    <section class="portfolio_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="title">Портфолио</h1>
                </div>
                <div class="col-lg-12">
                    <div class="breadcrumbs_box">
                        <form id="accordion" action="" method="post">
                            <ul class="nav first_cat">
                                <?php $terms = get_terms(
                                    array(
                                        'taxonomy' => 'category',
                                        'hide_empty' => false,
                                        'parent' => 0,
                                        'order' => 'DESC',
                                        'include' => array(
                                            35, 34
                                        ),
                                    )
                                ); ?>
                                <li><a class="active" href="#">Все кейсы</a></li>
                                <?php foreach ($terms as $term): ?>
                                    <li>
                                        <a href="#Collapse<?php echo $term->term_id ?>" data-toggle="collapse"
                                           data-id="coll<?php echo $term->term_id ?>" id="<?php echo $term->term_id ?>"
                                           data-text="<?php echo $term->slug ?>" href="#"><?php echo $term->name ?></a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <?php foreach ($terms as $term): ?>
                                <?php $current_cat_id = $term->term_id; ?>
                                <?php $args = array(
                                    'child_of' => $current_cat_id,
                                    'orderby' => 'name',
                                    'order' => 'ASC',
                                    'hide_empty' => 1,
                                    'hierarchical' => 1,
                                    'number' => 0,
                                );
                                $categories = get_categories($args);
                                ?>
                                <?php if ($categories): ?>
                                    <ul data-toggle="buttons" data-id="coll<?php echo $term->term_id ?>"
                                        data-parent="#accordion" id="Collapse<?php echo $term->term_id ?>"
                                        class="nav collapse  child_terms">
                                        <?php foreach ($categories as $cat): ?>
                                            <li>
                                                <a data-toggle="tab" data-id="coll<?php echo $cat->term_id ?>"
                                                   id="<?php echo $cat->term_id ?>" href=""><?php echo $cat->name ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid ml-0 mr-0 pt-4">
            <?php global $post; ?>
            <?php $args = array(
                'post_type' => 'case',
                'posts_per_page' => -1,
                'order' => 'ASC',
                'post_status' => 'publish',
            ); ?>
            <?php $loop = new WP_Query($args); ?>
            <div class="row cases_row ml-0 mr-0">
                <?php while ($loop->have_posts()) : $loop->the_post(); ?>
                    <div class="col-lg-3">
                        <div class="case" style="background-image: url(<?php echo get_the_post_thumbnail_url(); ?>)">
                            <p class="slide_title"><?php the_title(); ?></p>
                            <p class="slide_short_text"><?php the_excerpt(); ?></p>
                            <div class="hidden_box">
                                <?php $categories = get_the_category($post->ID); ?>
                                <?php if ($categories): ?>
                                    <ul class="breadcrumbs_list nav">

                                        <?php foreach ($categories as $category): ?>
                                            <li>
                                                <a href="<?php echo get_category_link($category->term_id); ?>"><?php echo $category->name; ?></a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                <?php endif; ?>
                                <?php $stat_case = get_field('stat'); ?>

                                <div class="row stat_row align-items-center">
                                    <?php foreach ($stat_case as $stat): ?>
                                        <div class="col-sm-6 d-flex align-items-center">
                                            <?php if ($stat['icon_stat']): ?>
                                                <img src="<?php echo $stat['icon_stat']; ?>" alt="">
                                            <?php else: ?>

                                            <?php endif; ?>
                                            <div class="info_side">
                                                <div class="quant"><?php echo $stat['quant_stat']; ?></div>
                                                <div class="text"><?php echo $stat['name_stat']; ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <a href=" <?php echo the_permalink() ?>" data-text="подробнее"
                                   class="btn_bordered">подробнее</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_query(); ?>
            </div>
        </div>
    </section>
<?php $check = get_field('video_block'); ?>
<?php if ($check): ?>
    <!--clients slider-->
    <section class="reviews_section pt-0 content pb-5" id="reviews_section">
        <div class="container">
            <div class="row">
                <h2 class="title">Видео отзывы</h2>
                <!--        video reviews-->
                <div class="video_review_row row">
                    <?php $youtube = get_field('youtube', 'option'); ?>
                    <?php foreach (array_slice($youtube, 0, 3) as $tube): ?>
                        <div class="col-lg-4">
                            <div class="video_reviews_box">
                                <div class="video_review">
                                    <div class="placeholder_reviews">
                                        <?php if ($tube['placeholder_video']): ?>
                                            <img src="<?php echo $tube['placeholder_video'] ?>" alt="">
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <div data-toggle="modal" data-src="https://www.youtube.com/embed/tgbNymZ7vqY"
                                             data-target="#modal_Video" class="btn_play">
                                            <i class="fa fa-play"></i>
                                        </div>
                                    </div>
                                    <iframe
                                            src="<?php echo $tube['tube_link']; ?>">
                                    </iframe>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="modal fade" id="modal_Video" tabindex="-1" role="dialog"
                         aria-labelledby="exampleModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog  modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <iframe class="embed-responsive-item" src="" id="video" allowscriptaccess="always"
                                        allow="autoplay"></iframe>
                            </div>
                        </div>
                    </div>
                    <div class="button_box">
                        <a href="https://testtimelife36.ru/otzyvy/" data-text="посмотреть все отзывы"
                           class="btn_bordered more">посмотреть
                            все отзывы</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--end of clients slider-->
<?php else: ?>
<?php endif; ?>

    <section class="section_04 pt-5" id="section_04">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="box_need">
                        <h2 class="title">Не получается увеличить продажи?</h2>
                        <p class="des">Мы точно знаем как вам помочь!</p>
                        <p class="text">Оставьте заявку и мы сделаем Вам уникальное предложение, которое подойдет именно<br>
                            Вам</p>
                        <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                            коммерческое
                            <br> предложение</a>
                    </div>
                </div>
                <div class="col-lg-6 contacts">
                    <img class="image wow fadeInRight" data-wow-offset="150" data-wow-delay="150" data-wow-duration="2s"
                         src="<?php echo get_template_directory_uri(); ?>/assets/img/cyber_02.png" alt="">
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>