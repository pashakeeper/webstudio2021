<?php
/*
    Template Name: Отзывы
    Template Post Type: post, page, product
*/
get_header(); ?>


    <!--reviews page-->
    <section class="reviews_section content" id="reviews_section">
        <div class="container">
            <div class="row">
                <h1 class="title">Отзывы и клиенты</h1>
                <p class="des">На этой странице вы можете ознакомиться с отзывами о нашей работе и увидеть с какими
                    компаниями и брендами мы работаем!</p>
                <h2 class="preslider_title mt-5">Наши клиенты</h2>
                <?php $cli = get_field('cli', 'option'); ?>
                <div class="slider_box">
                    <div class="slider_clients">
                        <?php foreach ($cli as $cli_item): ?>
                            <a href="<?php echo $cli_item['link_cli']; ?>"><img
                                        src="<?php echo $cli_item['image_cli']; ?>" alt=""></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <p class="preslider_title">Отзывы клиентов</p>
                <!--            Slider box-->
                <div class="slider_box_review w-100 mt-5">
                    <?php $rev = get_field('review', 'option'); ?>
                    <!--                slider-->
                    <div class="slider_reviews" id="page_rev">
                        <!--                    slide-->
                        <?php foreach ($rev as $review): ?>
                            <div class="slide">
                                <div class="slider_header d-flex">
                                    <div class="image_holder">
                                        <img src="<?php echo $review['ava'] ?>" alt="">
                                        <span><i class="fab fa-vk"></i></span>
                                    </div>
                                    <div class="text_side">
                                        <h4 class="review_name"><?php echo $review['name'] ?></h4>
                                        <p class="review_service"><?php echo $review['work'] ?></p>
                                    </div>
                                </div>
                                <div class="slider_content">
                                    <?php echo $review['review01']; ?>
                                </div>
                            </div>
                            <!--                    emd of slide-->
                        <?php endforeach; ?>
                    </div>
                    <!--                end of slider-->
                </div>
                <!--            end of slider box-->
            </div>
            <!--        video reviews-->
            <div class="video_review_row row">
                <?php if (have_rows('youtube', 'option')): ?>
                    <?php while (have_rows('youtube', 'option')) : the_row(); ?>
                        <div class="col-lg-4">
                            <div class="video_reviews_box">
                                <div class="video_review">
                                    <div class="placeholder_reviews">
                                        <?php if (get_sub_field('placeholder_video')): ?>
                                            <img src="<?php echo get_sub_field('placeholder_video') ?>" alt="">
                                        <?php else: ?>
                                        <?php endif; ?>
                                        <div data-toggle="modal" data-src="<?php echo get_sub_field('tube_link'); ?>"
                                             data-target="#modal_Video" class="btn_play">
                                            <i class="fa fa-play"></i>
                                        </div>
                                    </div>
                                    <iframe
                                            src="<?php echo get_sub_field('tube_link'); ?>">
                                    </iframe>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
                <div class="modal fade" id="modal_Video" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog  modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <iframe class="embed-responsive-item" src="" id="video" allowscriptaccess="always"
                                    allow="autoplay"></iframe>
                        </div>
                    </div>
                </div>
                <div class="button_box">
                    <a href="#" data-text="посмотреть все отзывы"
                       class="btn_bordered more more_video">посмотреть
                        все отзывы</a>
                </div>
            </div>
        </div>
        <div class="container action_box">
            <div class="row align-items-center">
                <?php $callrev = get_field('call_to_action_reviews', 'option') ?>
                <div class="col-lg-5">
                    <div class="box_need">
                        <?php echo $callrev['content_rev']; ?>
                        <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                            коммерческое предложение</a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <img class="image" src="<?php echo $callrev['image_rev']; ?>" alt="">
                </div>
            </div>
        </div>
    </section>
    <!--end of reviews page-->


<?php get_footer(); ?>