<?php
/*
    Template Name: Главная страница
    Template Post Type: post, page, product
*/
get_header(); ?>


<section class="main_section" id="main_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="main_title text-center">
                    <?php echo get_field('main_title', 'option'); ?>
                </div>
            </div>
            <?php $small_links = get_field('links_after_title', 'option'); ?>
            <div class="col-lg-12">
                <ul class="main_after_list nav justify-content-center">
                    <?php foreach ($small_links as $links): ?>
                        <li class="li"><img src="<?php echo $links['icon'] ?>" alt="main-icon1"><a
                                    href="<?php echo $links['link'] ?>"><?php echo $links['link_text'] ?></a></li>
                    <?php endforeach; ?>

                </ul>
            </div>
            <div class="col-lg-12">
                <a href="#" data-text="Заказать увеличение продаж" class="btn_bordered main_btn">Заказать увеличение
                    продаж</a>
            </div>
        </div>
    </div>
    <div class="marquee left">
        <ul class="nav marquee_ul">
            <?php $run_left = get_field('run_links', 'option'); ?>
            <?php foreach ($run_left as $run_l): ?>
                <li><a href="<?php echo $run_l['some_link_1'] ?>"><?php echo $run_l['somelink_text_1'] ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="marquee right">
        <ul class="nav marquee_ul">
            <?php $run_left = get_field('run_links_2', 'option'); ?>
            <?php foreach ($run_left as $run_l): ?>
                <li><a href="<?php echo $run_l['some_link_2'] ?>"><?php echo $run_l['somelink_text_2'] ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
<section class="sevices_section" id="services_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title">Наши услуги</h2>
            </div>
        </div>
        <div class="row serv_row">
            <?php $services = get_field('services_page', 54); ?>
            <?php foreach (array_slice($services, 0, 6) as $serv_item): ?>
                <div class="col-lg-4">
                    <div class="serv_box">
                        <div class="serv_box__image_holder">
                            <img src="<?php echo $serv_item['image_serv']; ?>" alt="">
                        </div>
                        <div class="serv_box_content">
                            <h3><?php echo $serv_item['title_serv'] ?></h3>
                            <?php
                            $maxchar = 152;
                            $text = strip_tags($serv_item['content_serv']);
                            echo mb_substr($text, 0, $maxchar);
                            ?>
                        </div>
                        <div class="price">Цена от <span><?php echo $serv_item['price_serv']; ?> ₽</span></div>
                        <a href="<?php echo $serv_item['link_serv'] ?>" data-text="Подробнее" class="btn_bordered">Подробнее</a>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="col-lg-12"><a data-text="все услуги и цены" href="https://testtimelife36.ru/uslugi-i-tseny/"
                                      class="all_serv btn_bordered">все услуги и цены</a></div>

        </div>
    </div>
</section>
<section class="portfolio_section" id="portfolio_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title">Наши работы</h2>
                <p class="des">Как мы помогли другим бизнесам и проделали качественную работу</p>
            </div>
        </div>
    </div>
    <div class="filter_box">
        <div class="container">
            <div class="filter_portfolio nav">
                <form method="post" action="" id="categoryfilter">
                    <?php if ($terms = get_terms(array('taxonomy' => 'category', 'orderby' => 'name', 'parent' => '35', 'hide_empty' => false))): ?>
                        <select class="select" id="select">
                            <option data-display="Выберите категорию...">Выберите категорию...</option>
                            <?php foreach ($terms as $term): ?>
                                <?php $trmname = $term->name; ?>
                                <option name="cat_name_front" id="<?php echo $trmname ?>"
                                        value="<?php echo $trmname ?>"><?php echo $trmname ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                </form>
                <div class="select_info">или используйте
                    <span class="select_info__btn">
                        <i class="fa fa-long-arrow-alt-up"></i>
                    </span>
                    <span class="select_info__btn">
                        <i class="fa fa-long-arrow-alt-down"></i>
                    </span> на клавиатуре для смены категории
                </div>
            </div>
        </div>
    </div>
    <div class="container content pt-0">
        <div class="row">
            <div class="col-lg-12">
                <?php
                $args = array(
                    'post_type' => 'case',
                    'posts_per_page' => -1,
                    'category_name' => '',
                    'paged' => 1,
                    'order' => 'ASC',
                ); ?>
                <!-- Slider-->
                <div class="slider_sell_page">
                    <?php if (query_posts($args)): ?>
                        <?php while (have_posts()) : the_post(); ?>
                            <!-- Slide-->
                            <div class="slide">
                                <div class="container">
                                    <?php $field_slide = get_field('kes__descr__true'); ?>
                                    <?php if ($field_slide): ?>
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <?php if (have_rows('kes__descr__left')):
                                                        while (have_rows('kes__descr__left')): the_row();
                                                            ?>
                                                            <p class="slider_title"><?php the_sub_field('kes__descr__left__title') ?></p>

                                                            <p class="slider_text"><?php the_sub_field('kes__descr__left__text') ?></p>
                                                            <div class="mobile_image mb-5">
                                                                <?php if (have_rows('kes__descr__right')):
                                                                    while (have_rows('kes__descr__right')): the_row();
                                                                        ?>
                                                                        <img class="right_image"
                                                                             src="<?php the_sub_field('kes__descr__right__img') ?>"
                                                                             alt="">
                                                                    <?php endwhile; ?>

                                                                <?php endif; ?>
                                                            </div>
                                                            <p class="slider_des"><?php the_sub_field('kes__descr__left__des') ?></p>
                                                            <img class="slider_frame"
                                                                 src="<?php the_sub_field('kes__descr__img') ?>" alt="">
                                                        <?php endwhile; ?>

                                                    <?php endif; ?>
                                                </div>
                                                <div class="col-lg-6">
                                                    <?php if (have_rows('kes__descr__right')):
                                                        while (have_rows('kes__descr__right')): the_row();
                                                            ?>
                                                            <img class="right_image"
                                                                 src="<?php the_sub_field('kes__descr__right__img') ?>"
                                                                 alt="">
                                                        <?php endwhile; ?>
                                                    <?php endif; ?>
                                                    <?php $video = get_field('kes__descr__right') ?>
                                                    <?php if ($video['video_image_case']): ?>
                                                        <div class=" content pt-0 pb-5">
                                                            <div class="video_reviews_box">
                                                                <div class="video_review">
                                                                    <div class="placeholder_reviews">
                                                                        <?php if ($video['video_image_case']): ?>
                                                                            <img src="<?php echo $video['video_image_case'] ?>" alt="">
                                                                        <?php else: ?>
                                                                        <?php endif; ?>
                                                                        <div data-toggle="modal" data-src="<?php echo $video['video_link_case']; ?>"
                                                                             data-target="#modal_Video" class="btn_play">
                                                                            <i class="fa fa-play"></i>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="row stat_row justify-content-center align-items-center">
                                                        <?php if (have_rows('kes__descr__vantage')): ?>
                                                            <?php while (have_rows('kes__descr__vantage')) : the_row(); ?>
                                                                <div class="col-md-6 d-flex justify-content-center align-items-center">
                                                                    <p><img loading="lazy"
                                                                            class="alignnone size-full wp-image-526"
                                                                            src="<?php the_sub_field('kes__descr__vantage__img'); ?>"
                                                                            alt="" width="64" height="64"></p>
                                                                    <div class="info_side">
                                                                        <p class="quant"><?php the_sub_field('kes__descr__vantage__title'); ?></p>
                                                                        <p class="text"><?php the_sub_field('kes__descr__vantage__text'); ?></p>
                                                                    </div>
                                                                </div>
                                                            <?php endwhile; ?>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="row btn_row">
                                                        <a class="more btn_bordered" href="<?php the_permalink(); ?>"
                                                           data-text="Подробнее" tabindex="0">Подробнее</a><br>
                                                        <a class="result btn_bordered" tabindex="0"
                                                           href="#" data-toggle="modal" data-target="#modal2"
                                                           data-text="хочу такие результаты">хочу такие результаты</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <h2><?php the_title(); ?></h2>
                                        <div class="row align-items-center">
                                            <div class="col-lg-12 text-center" style="max-height: 750px;height: 100%;">
                                                <img style="max-height: 500px"
                                                     src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/no_info.jpg"
                                                     alt="">
                                                <h1 class="second_title">К сожалению нету краткого описания</h1>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!--                    end of slide-->
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
                <!--                end of slider-->
            </div>
        </div>
    </div>
</section>
<section class="section_04" id="section_04">
    <div class="container">
        <div class="row align-items-center">
            <?php $call_1 = get_field('main_call_toaction_1', 'option'); ?>
            <div class="col-lg-6">
                <div class="box_need">
                    <?php echo $call_1['left_side_text']; ?>
                    <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить коммерческое
                        <br> предложение</a>
                </div>
            </div>
            <div class="col-lg-6">
                <img class="image wow fadeInRight" data-wow-offset="150" data-wow-delay="150" data-wow-duration="2s"
                     src="<?php echo $call_1['image01'] ?>" alt="">
            </div>
        </div>
    </div>
</section>

<section class="about_section" id="about_section">
    <div class="container">
        <?php $about = get_field('about_company', 'option'); ?>
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about_box">
                    <?php echo $about['left_side_text']; ?>
                    <div class="about_info_row row">
                        <?php $stat = $about['stat'] ?>
                        <?php foreach ($stat as $statitem): ?>
                            <div class="col-lg-4 col-md-4 d-flex">
                                <img src="<?php echo $statitem['img']; ?>" alt=""
                                     class="info_row__img">
                                <div class="info_row__text">
                                    <?php echo $statitem['content']; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="#" data-text="читать полностью" class="btn_bordered read_about">читать полностью</a>
                </div>
            </div>
            <div class="col-lg-6 about_resp">
                <div class="about__image_holder"><img
                            src="<?php echo get_template_directory_uri(); ?>/assets/img/about_img.png" alt=""></div>
            </div>
            <div class="canvas_container">
                <div class="dots dot01"><i class="fa fa-circle"></i></div>
                <div class="line"></div>
                <div class="dots dot02"><i class="fa fa-circle"></i></div>
            </div>
            <div class="col-lg-12">
                <div class="about_hide_content">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <?php echo $about['hide_text_left']; ?>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <?php echo $about['hide_text_right']; ?>
                        </div>
                    </div>
                    <a href="#" data-text="скрыть" class="btn_bordered hide">скрыть</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--team section-->
<section class="team_section" id="team_section">
    <div class="container">
        <div class="row justify-content-center team_content">
            <div class="col-lg-12">
                <h2 class="title">Наша команда</h2>
            </div>
            <?php if (have_rows('team_field', 'option')): ?>
                <?php while (have_rows('team_field', 'option')) : the_row(); ?>

                    <div class="col">
                        <div class="team_box">
                            <div class="team_image_holder"
                                 style="background-image:url('<?php echo the_sub_field('avatar_team') ?>');">
                                <p class="position_eng"><?php echo the_sub_field('position_eng_team') ?></p>
                            </div>
                            <h3 class="name"><?php echo the_sub_field('name_team') ?></h3>
                            <p class="position_ru"><?php echo the_sub_field('position_team') ?></p>
                        </div>
                    </div>
                    <?php endwhile; ?>
            <?php endif; ?>
        </div>
        <div class="col-lg-12">
                <a  href="#" data-clicks="true" name="more_team" data-text="Показать всех"
                   class="btn_bordered more_team">Показать всех</a>
        </div>
    </div>
</section>

<!--end of team section-->


<!--why section-->
<section class="why_we" id="why_we">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="title">Почему именно мы?</h2>
            </div>
            <?php $why = get_field('why_field', 'option'); ?>
            <?php foreach ($why as $whyitem): ?>
                <div class="col-lg-3">
                    <div class="why_box">
                        <img src="<?php echo $whyitem['icon_why'] ?>" alt="">
                        <p class="why_title"><?php echo $whyitem['title_why']; ?></p>
                        <p class="why_text"><?php echo $whyitem['text_why']; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php wp_reset_query(); ?>
        </div>
    </div>
</section>

<!--clients slider-->
<section class="reviews_section content" id="reviews_section">
    <div class="container">
        <div class="row">
            <h2 class="title">Наши клиенты</h2>
            <?php $cli = get_field('cli', 'option'); ?>
            <div class="slider_box">
                <div class="slider_clients">
                    <?php foreach ($cli as $cli_item): ?>
                        <a href="<?php echo $cli_item['link_cli']; ?>"><img src="<?php echo $cli_item['image_cli']; ?>"
                                                                            alt=""></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <h2 class="title">Наши отзывы</h2>
            <!--            Slider box-->
            <div class="slider_box_review">
                <?php $rev = get_field('review', 'option'); ?>
                <!--                slider-->
                <div class="slider_reviews">
                    <!--                    slide-->
                    <?php foreach ($rev as $review): ?>
                        <div class="slide">
                            <div class="slider_header d-flex">
                                <div class="image_holder">
                                    <img src="<?php echo $review['ava'] ?>" alt="">
                                    <?php if ($review['image_rev']): ?>
                                        <span><img src="<?php echo $review['image_rev'] ?>" alt=""></span>
                                    <?php else: ?>
                                        <span><a href="<?php echo $review['image_rev_link'] ?>"></a><i
                                                    class="fab fa-vk"></i></span>
                                    <?php endif; ?>
                                </div>
                                <div class="text_side">
                                    <h4 class="review_name"><?php echo $review['name'] ?></h4>
                                    <p class="review_service"><?php echo $review['work'] ?></p>
                                </div>
                                <?php if ($review['logo_partners']): ?>
                                    <div class="col-sm-6 ml-auto">
                                        <a href="<?php echo $review['link_partners'] ?>" class="partners_link">
                                            <img src="<?php echo $review['logo_partners'] ?>" alt="">
                                        </a>
                                    </div>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                            <div class="slider_content">
                                <?php echo $review['review01']; ?>
                            </div>
                        </div>
                        <!--                    emd of slide-->
                    <?php endforeach; ?>
                </div>
                <!--                end of slider-->
            </div>
            <!--            end of slider box-->
            <!--        video reviews-->
            <div class="video_review_row row">
                <?php $youtube = get_field('youtube', 'option'); ?>
                <?php foreach (array_slice($youtube, 0, 3) as $tube): ?>
                    <div class="col-lg-4">
                        <div class="video_reviews_box">
                            <div class="video_review">
                                <div class="placeholder_reviews">
                                    <?php if ($tube['placeholder_video']): ?>
                                        <img src="<?php echo $tube['placeholder_video'] ?>" alt="">
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <div data-toggle="modal" data-src="<?php echo $tube['tube_link']; ?>"
                                         data-target="#modal_Video" class="btn_play">
                                        <i class="fa fa-play"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="modal fade" id="modal_Video" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog  modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <?php if (strnatcmp($video['video_image_case'], 'https://testtimelife36.ru/wp-content/uploads/') == 17 ||  var_dump(strnatcmp($video['video_image_case'], 'https://testtimelife36.ru/wp-content/uploads/')) == 20 ): ?>
                            <?php else: ?>
                            <iframe class="embed-responsive-item" src="" id="video" allowscriptaccess="always" autoplay="false" ></iframe>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="button_box">
                    <a href="https://testtimelife36.ru/otzyvy/" data-text="посмотреть все отзывы"
                       class="btn_bordered more">посмотреть
                        все отзывы</a>
                </div>
            </div>
        </div>
        <div class="container action_box">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <div class="box_need">
                        <h2 class="title">Нужен сайт
                            или продвижение?</h2>
                        <p class="des">Мы точно знаем как вам помочь!</p>
                        <p class="text">Оставьте заявку и мы сделаем Вам уникальное предложение, которое подойдет именно
                            Вам</p>
                        <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                            коммерческое <br> предложение</a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <img class="image" src="<?php echo get_template_directory_uri(); ?>/assets/img/cyber_01.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!--end of clients slider-->
<?php get_footer(); ?>
