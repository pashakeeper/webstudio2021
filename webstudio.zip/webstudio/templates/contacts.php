<?php
/*
    Template Name: Контакты
    Template Post Type: post, page, product
*/
get_header(); ?>
    <section class="contact_section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12"><h1 class="title">Контакты</h1></div>
                <div class="col-lg-6 col-md-6 contacts_container">
                    <div class="contact_main_box">
                        <div class="contact_box">
                            <a href="tel:<?php the_field('phone_format', 'option'); ?>" class="phone"><i
                                        class="fa fa-phone-alt"></i><?php the_field('phone', 'option'); ?></a>
                        </div>
                        <?php $info = get_field('email', 'option') ?>
                        <?php foreach ($info as $item): ?>
                            <div class="contact_box">
                                <i class="fa fa-envelope"></i>
                                <a href="#"><?php echo $item['mail']; ?></a>
                            </div>
                        <?php endforeach; ?>
                        <div class="contact_box">
                            <i class="fas fa-map-marker-alt"></i>
                            <a href="#" class="address">
                                <?php the_field('address', 'option'); ?>
                            </a>
                        </div>
                        <div class="contact_box">
                            <?php $social = get_field('social', 'option') ?>
                            <ul class="social nav">
                                <li><a href="<?php echo $social['instagram']; ?>"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li><a href="<?php echo $social['facebook']; ?>"><i class="fab fa-facebook-square"></i></a>
                                </li>
                                <li><a href="<?php echo $social['youtube']; ?>"><i
                                                class="fab fa-youtube-square"></i></a></li>
                                <li><a href="<?php echo $social['vk']; ?>"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 maps_container">
                    <div id="map"></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section_04 contacts" id="section_04">
        <div class="container">
            <div class="row align-items-center">
                <?php $callrev = get_field('call_to_action_contact', 'option') ?>
                <div class="col-lg-5">
                    <div class="box_need">
                        <?php echo $callrev['content_contact']; ?>
                        <a href="#" data-text="Получить коммерческое предложение" class="btn_bordered">Получить
                            коммерческое предложение</a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <img class="image" src="<?php echo $callrev['image_contact']; ?>" alt="">
                </div>
            </div>
        </div>
    </section>

    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBs_1a5jFZ_JeddJJyKqeSIfHCJ8zYjvRc&callback=initMap&libraries=&v=weekly"
            async></script>
    <script>
        let stylesArray = [
            {
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#212121"
                    }
                ]
            },
            {
                "elementType": "labels.icon",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#757575"
                    }
                ]
            },
            {
                "elementType": "labels.text.stroke",
                "stylers": [
                    {
                        "color": "#212121"
                    }
                ]
            },
            {
                "featureType": "administrative",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#757575"
                    }
                ]
            },
            {
                "featureType": "administrative.country",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#9e9e9e"
                    }
                ]
            },
            {
                "featureType": "administrative.land_parcel",
                "stylers": [
                    {
                        "visibility": "off"
                    }
                ]
            },
            {
                "featureType": "administrative.locality",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#bdbdbd"
                    }
                ]
            },
            {
                "featureType": "poi",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#757575"
                    }
                ]
            },
            {
                "featureType": "poi.park",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#181818"
                    }
                ]
            },
            {
                "featureType": "poi.park",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#616161"
                    }
                ]
            },
            {
                "featureType": "poi.park",
                "elementType": "labels.text.stroke",
                "stylers": [
                    {
                        "color": "#1b1b1b"
                    }
                ]
            },
            {
                "featureType": "road",
                "elementType": "geometry.fill",
                "stylers": [
                    {
                        "color": "#2c2c2c"
                    }
                ]
            },
            {
                "featureType": "road",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#8a8a8a"
                    }
                ]
            },
            {
                "featureType": "road.arterial",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#373737"
                    }
                ]
            },
            {
                "featureType": "road.highway",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#3c3c3c"
                    }
                ]
            },
            {
                "featureType": "road.highway.controlled_access",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#4e4e4e"
                    }
                ]
            },
            {
                "featureType": "road.local",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#616161"
                    }
                ]
            },
            {
                "featureType": "transit",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#757575"
                    }
                ]
            },
            {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [
                    {
                        "color": "#000000"
                    }
                ]
            },
            {
                "featureType": "water",
                "elementType": "labels.text.fill",
                "stylers": [
                    {
                        "color": "#3d3d3d"
                    }
                ]
            }
        ]

        let map

        let markers = []

        const myLatLng = {
            lat: 51.678638,
            lng: 39.185699
        }

        const markerIcon = 'https://testtimelife36.ru/wp-content/themes/webstudio/assets/img/icons/marker.png'

        const initMap = () => {
            let mapOptions = {
                center: new google.maps.LatLng(myLatLng.lat, myLatLng.lng),
                zoom: 16.5,
                styles: stylesArray,
                disableDefaultUI: true,
            }

            map = new google.maps.Map(document.getElementById('map'), mapOptions)

            let directionsDisplay = new google.maps.DirectionsRenderer()
            let directionsService = new google.maps.DirectionsService()
            directionsDisplay.setMap(map)
            directionsDisplay.setOptions({
                suppressMarkers: true,
                suppressInfoWindows: true
            })

            // Начальная точка
            let startPoint = new google.maps.LatLng(myLatLng.lat, myLatLng.lng)

            // Маркер начальной точки
            new google.maps.Marker({
                position: startPoint,
                map: map,
                icon: markerIcon
            })

            map.addListener("click", (mapsMouseEvent) => {
                // Получение новой точки по клику
                let secondPoint = mapsMouseEvent.latLng

                // Добавление маркера для новой точки
                addMarker(secondPoint)

                // Вызов функции получения маршрута
                getDirections({ startPoint, secondPoint, directionsDisplay, directionsService })
            })
        }

        // Функция получения маршрута
        const getDirections = ({ startPoint, secondPoint, directionsDisplay, directionsService }) => {
            // Параметры запроса маршрута
            let request = {
                origin: startPoint,
                destination: secondPoint,
                travelMode: google.maps.TravelMode.DRIVING,
                unitSystem: google.maps.UnitSystem.METRIC,
                provideRouteAlternatives: true,
                avoidHighways: false,
                avoidTolls: true
            }

            // Запрос и отображение маршрута
            directionsService.route(request, function(result, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(result)

                    // Добавление информации о маршруте
                    let routes = result.routes
                    let leg = routes[0].legs
                    let lenght = leg[0].distance.text
                    let duration = leg[0].duration.text

                    infowindow = new google.maps.InfoWindow({
                        content: 'Дистанция: '+ lenght +'<br>Продолжительность: '+ duration
                    })

                    infowindow.open(map, markers[0])
                }
            })
        }

        // Функция добавления маркера
        const addMarker = position => {
            // Удаляем предыдущий маркер
            for (let i = 0; i < markers.length; i++) {
                markers[i].setMap(null)
            }
            markers = []

            // Создаём новый маркер
            const marker = new google.maps.Marker({
                position,
                map,
                icon: markerIcon
            })

            markers.push(marker)
        }
        google.maps.event.addDomListener(window, 'load', initMap)
    </script>
<?php get_footer(); ?>